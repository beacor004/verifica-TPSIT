const WebSocket = require('ws');
const prompt = require('prompt-sync')({sigint:true}); 

const ServerAddress="ws://127.0.0.1:5000";

const socket = new WebSocket(ServerAddress);

var parola;
var num = 0;

socket.on('message', function (parola) {
   parola = prompt("inserisci la parola" );
   console.log("hai ricevuto:" + parola); 
});


socket.on('message', function (num) {
   num = prompt("inserisci il numero " );
   
});




