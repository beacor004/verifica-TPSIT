const WebSocket = require("ws");// per includere un modulo usiamo
const PORT = 5000;
const wsServer = new WebSocket.Server({
    
    port: PORT
}); 
console.log("Il Server è attivo e aspetta pacchetti sulla porta " + wsServer.options.port );


wsServer.on("connection" , function(socket) {
    socket.send("la tua connessione è stata accettata dal server");
});

var giusta; //per vedere se è la parola giusta

    socket.on("message" , function(parola) {
        
        if(parola=="moltiplica")
        {
            giusta = 'moltiplica';
            console.log("Hai scelto la parola " + parola);
            
        }
        else if(parola=="raddoppia") {

            giusta = 'raddoppia';
            console.log("Hai scelto la parola " + parola);
            
        }
        else if(parola=="fattoriale")
        {
            giusta = 'fattoriale';
            console.log("Hai scelto la parola " + parola);
            
            
        }        
    });


//a seconda della stringa fa l'operazione desiderata
    socket.on("message" , function(giusta) {
    
        if(giusta=='moltiplica')
        {
            socket.send(num*2);
        }
        else if(giusta=='raddoppia') {
            
            socket.send(num*num);
            
        }
        else if(giusta=='fattoriale')
        {
            var risultato = 1;
            for (var i = 1; i <= num; i++) {
              risultato *= i;
            }   
            
        }
    });






